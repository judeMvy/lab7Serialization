﻿using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace serializationlab
{


    [Serializable]
    internal class Event 
    {
        public int EventNumber { get; set; }
        public string Location { get; set; }

        //public Event() { }
        public Event(int eventNumber = 1, string location = "Calgary")
        {
            EventNumber = eventNumber;
            Location = location;
        }

        

        /*public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("EventNumber", EventNumber);
            info.AddValue("Location", Location);
        }

        public Event(SerializationInfo info, StreamingContext context)
        {
            EventNumber = info.GetInt32("EventNumber");
            Location = info.GetString("Location");

        }*/



    }
}