﻿using System;
using System.Collections;
using System.Collections.Generic;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Text.Json;

namespace serializationlab
{

    internal class Program
    {
        static void Main(string[] args)
        {


            Event events = new Event(1, "Calgary");

            //SERIALIZE 
            JsonSerializer.Serialize(events);

            string encoded = JsonSerializer.Serialize(events);
            File.WriteAllText("event.txt", encoded);

            //DESERIALIZE 
            string content = File.ReadAllText("event.txt");
            Event decoded = JsonSerializer.Deserialize<Event>(content); 

            Console.WriteLine(decoded.EventNumber);
            Console.WriteLine(decoded.Location);


            //p3: print first, mid, last of HACKATHON word
            using (StreamWriter writer = new StreamWriter("hackathon.txt")) 
            {
                writer.Write("Hackathon");
            }

            //READ HACKATHON, seek , flush -> discard first
            using(StreamReader reader = new StreamReader("hackathon.txt"))
            {
                Console.WriteLine(reader.ReadToEnd());

                Console.WriteLine("Tech Competition");
             
                reader.BaseStream.Seek(0, SeekOrigin.Begin);
                Console.WriteLine("The first character: \"{0}\"", (char)reader.Read());

                reader.DiscardBufferedData();
                reader.BaseStream.Seek(4, SeekOrigin.Begin);
                Console.WriteLine("The middle Character: \"{0}\"", (char)reader.Read());

                reader.DiscardBufferedData();
                reader.BaseStream.Seek(8, SeekOrigin.Begin);
                Console.WriteLine("The last Character: \"{0}\"", (char)reader.Read());


            }

        }

    }
}